package com.javaGraphQL.hplus;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HplusApplicationTests {

	@Test
	void contextLoads() {
	}

}
